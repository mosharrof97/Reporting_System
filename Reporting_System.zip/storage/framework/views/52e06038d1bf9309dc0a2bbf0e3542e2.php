<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Marketing Report</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table primary-table  table-bordered table-responsive-sm">
                            <thead class="thead-primary">
                                <tr>
                                    <th scope="col"> SL </th>
                                    <th scope="col">Date</th>
                                    <th scope="col">School Name</th>
                                    <th scope="col"> EIIN </th>
                                    <th scope="col">Head Teacher</th>
                                    <th scope="col">Mobile No</th>
                                    <th scope="col">District</th>
                                    <th scope="col"> Upazila</th>
                                    <th scope="col">Visit Count</th>
                                    <th scope="col">Comment</th>
                                    <th scope="col">TA Bill Sell</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">DMO</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $submitReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($datas->id); ?></td>
                                        <td><?php echo e($datas->created_at); ?></td>
                                        <td><?php echo e($datas->school_name); ?></td>
                                        <td><?php echo e($datas->eiin_number); ?></td>
                                        <td><?php echo e($datas->h_teacher_name); ?></td>
                                        <td><?php echo e($datas->number); ?></td>
                                        <td><?php echo e($datas->district); ?></td>
                                        <td><?php echo e($datas->upazila); ?></td>
                                        <td><?php echo e($datas->upazila); ?></td>
                                        <td><?php echo e($datas->school_comment); ?></td>
                                        <td><?php echo e($datas->t_a_bill); ?></td>
                                        <td><?php echo e($datas->visit_status); ?></td>
                                        <td><?php echo e($datas->visit_status); ?></td>
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userDashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Project\Reporting_System\resources\views/userDashboard/page/report_List.blade.php ENDPATH**/ ?>