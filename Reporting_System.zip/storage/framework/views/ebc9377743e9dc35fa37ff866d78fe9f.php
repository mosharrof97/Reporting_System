<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">

                <div class="card-header">
                    <h4 class="card-title">Submit Report</h4>
                </div>

                <div class="card-body">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="previous_school"
                                placeholder="Select Previous School">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="school_name"
                                placeholder="School Name ">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="h_teacher_name "
                                placeholder="Head Teacher Name ">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="number"
                                placeholder="Mobile Number">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="eiin_number "
                                placeholder="EIIN Number ">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="district "
                                placeholder="Select District ">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="upazila "
                                placeholder="Select Upazila">
                        </div>

                        <div class="mb-3">
                            <select class="form-control" name="visit_status" id="">
                                <option value="">Select Visit Status</option>
                                <option value="Negative">Negative</option>
                                <option value="Positive">Positive</option>
                                <option value="Confirmed ">Confirmed </option>
                            </select>

                            
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="school_omment  "
                                placeholder="Type School Comment ">
                        </div>

                        <div class="mb-3">
                            <input type="file" class="form-control" id="" name="image"
                                placeholder="Upload Photo">
                        </div>

                        <div class="mb-3">
                            <input type="text" class="form-control" id="" name="t_a_bill"
                                placeholder="T. A Bill (tk)">
                        </div>

                        <div class="mb-3 text-end">
                            <input type="submit" class="btn btn-primary" value="Submit form">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('userDashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel Project\Reporting_System\resources\views/userDashboard\page\submit_Report.blade.php ENDPATH**/ ?>