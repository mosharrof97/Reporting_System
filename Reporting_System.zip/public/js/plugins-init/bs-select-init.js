(function ($) {
    "use strict"

})(jQuery);